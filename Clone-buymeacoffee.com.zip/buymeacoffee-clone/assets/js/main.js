/**
 * BuyMeACoffee Clone - Main JavaScript
 */
document.addEventListener('DOMContentLoaded', function() {
    // Flash message auto-dismiss
    const flashMessage = document.getElementById('msg-flash');
    if (flashMessage) {
        setTimeout(function() {
            flashMessage.style.opacity = '0';
            setTimeout(function() {
                flashMessage.style.display = 'none';
            }, 300);
        }, 5000);
    }

    // Coffee options selection
    const coffeeOptions = document.querySelectorAll('.coffee-option');
    if (coffeeOptions.length > 0) {
        coffeeOptions.forEach(option => {
            option.addEventListener('click', function() {
                // Remove active class from all options
                coffeeOptions.forEach(opt => opt.classList.remove('active'));
                // Add active class to selected option
                this.classList.add('active');
                // Update hidden input with selected value
                document.getElementById('coffee-amount').value = this.getAttribute('data-amount');
                // Update total in the button if present
                const coffeeButton = document.querySelector('.coffee-button');
                if (coffeeButton) {
                    const coffeePrice = 5; // Default price per coffee
                    const coffeeCount = parseInt(this.getAttribute('data-amount'));
                    const total = coffeePrice * coffeeCount;
                    coffeeButton.textContent = `Support $${total}`;
                }
            });
        });
    }

    // Monthly subscription toggle
    const monthlyToggle = document.getElementById('monthly-toggle');
    if (monthlyToggle) {
        monthlyToggle.addEventListener('change', function() {
            document.getElementById('is-monthly').value = this.checked ? '1' : '0';

            // Update button text
            const coffeeButton = document.querySelector('.coffee-button');
            if (coffeeButton) {
                if (this.checked) {
                    coffeeButton.textContent = coffeeButton.textContent + ' monthly';
                } else {
                    coffeeButton.textContent = coffeeButton.textContent.replace(' monthly', '');
                }
            }
        });
    }

    // Profile tabs
    const profileTabs = document.querySelectorAll('.profile-tab');
    if (profileTabs.length > 0) {
        profileTabs.forEach(tab => {
            tab.addEventListener('click', function() {
                // Remove active class from all tabs
                profileTabs.forEach(t => t.classList.remove('active'));
                // Add active class to clicked tab
                this.classList.add('active');

                // Hide all tab content
                const tabContents = document.querySelectorAll('.tab-content');
                tabContents.forEach(content => content.style.display = 'none');

                // Show selected tab content
                const tabId = this.getAttribute('data-tab');
                document.getElementById(tabId).style.display = 'block';
            });
        });
    }

    // Membership tier selection
    const membershipTiers = document.querySelectorAll('.membership-tier');
    if (membershipTiers.length > 0) {
        membershipTiers.forEach(tier => {
            tier.addEventListener('click', function() {
                // Remove selected class from all tiers
                membershipTiers.forEach(t => t.classList.remove('selected'));
                // Add selected class to clicked tier
                this.classList.add('selected');

                // Update hidden input with selected tier ID
                document.getElementById('membership-id').value = this.getAttribute('data-id');

                // Update button text with tier price
                const subscribeButton = document.querySelector('.subscribe-button');
                if (subscribeButton) {
                    const tierPrice = this.getAttribute('data-price');
                    subscribeButton.textContent = `Subscribe $${tierPrice}/month`;
                }
            });
        });
    }

    // Form validation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            let hasError = false;

            // Check required fields
            const requiredFields = form.querySelectorAll('[required]');
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.classList.add('error');
                    hasError = true;

                    // Add error message if not exists
                    let errorMessage = field.nextElementSibling;
                    if (!errorMessage || !errorMessage.classList.contains('error-message')) {
                        errorMessage = document.createElement('div');
                        errorMessage.classList.add('error-message');
                        errorMessage.textContent = 'This field is required';
                        field.parentNode.insertBefore(errorMessage, field.nextSibling);
                    }
                } else {
                    field.classList.remove('error');

                    // Remove error message if exists
                    const errorMessage = field.nextElementSibling;
                    if (errorMessage && errorMessage.classList.contains('error-message')) {
                        errorMessage.remove();
                    }
                }
            });

            // Email validation
            const emailFields = form.querySelectorAll('input[type="email"]');
            emailFields.forEach(field => {
                if (field.value.trim() && !isValidEmail(field.value)) {
                    field.classList.add('error');
                    hasError = true;

                    // Add error message if not exists
                    let errorMessage = field.nextElementSibling;
                    if (!errorMessage || !errorMessage.classList.contains('error-message')) {
                        errorMessage = document.createElement('div');
                        errorMessage.classList.add('error-message');
                        errorMessage.textContent = 'Please enter a valid email address';
                        field.parentNode.insertBefore(errorMessage, field.nextSibling);
                    }
                }
            });

            if (hasError) {
                event.preventDefault();
            }
        });
    });

    // Handle character counter for message input
    const messageInput = document.getElementById('message');
    if (messageInput) {
        const charCounter = document.getElementById('char-counter');
        const maxLength = messageInput.getAttribute('maxlength') || 280;

        messageInput.addEventListener('input', function() {
            const remaining = maxLength - this.value.length;
            if (charCounter) {
                charCounter.textContent = `${remaining} characters remaining`;

                if (remaining < 20) {
                    charCounter.classList.add('warning');
                } else {
                    charCounter.classList.remove('warning');
                }
            }
        });
    }
});

/**
 * Validate email format
 *
 * @param {string} email Email to validate
 * @return {boolean} Is valid email
 */
function isValidEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}
