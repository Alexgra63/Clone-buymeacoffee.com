<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buy Me a Coffee</title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <main>
        <!-- Main content goes here -->
    </main>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Buy Me a Coffee</h3>
                    <ul>
                        <li><a href="<?php echo BASE_URL; ?>/about.php">About</a></li>
                        <li><a href="https://help.buymeacoffee.com/en/">Help Center</a></li>
                    </ul>
                </div>

                <div class="footer-section">
                    <h3>Apps</h3>
                    <ul>
                        <li><a href="https://apps.apple.com/in/app/buy-me-a-coffee/id1480229954">iOS</a></li>
                        <li><a href="https://play.google.com/store/apps/details?id=app.buymeacoffee">Android</a></li>
                    </ul>
                </div>

                <div class="footer-section">
                    <h3>Resources</h3>
                    <ul>
                        <li><a href="#">Feature requests</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/brand.php">Buttons</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/ko-fi-alternative.php">Ko-fi comparison</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/patreon-alternative.php">Patreon comparison</a></li>
                        <li><a href="#">Link in Bio</a></li>
                        <li><a href="#">Voicenotes</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/security.php">Security policy</a></li>
                    </ul>
                </div>
            </div>

            <div class="footer-bottom">
                <div class="footer-logo">
                    <a href="<?php echo BASE_URL; ?>">
                        <img src="<?php echo BASE_URL; ?>/assets/img/logo.svg" alt="Buy Me a Coffee">
                    </a>
                </div>

                <div class="footer-links">
                    <a href="<?php echo BASE_URL; ?>/privacy-policy.php">Privacy</a>
                    <a href="<?php echo BASE_URL; ?>/terms.php">Terms</a>
                </div>

                <div class="social-links">
                    <a href="https://twitter.com/buymeacoffee" target="_blank" aria-label="Twitter">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="https://www.youtube.com/buymeacoffee" target="_blank" aria-label="YouTube">
                        <i class="fab fa-youtube"></i>
                    </a>
                    <a href="https://www.instagram.com/buymeacoffee" target="_blank" aria-label="Instagram">
                        <i class="fab fa-instagram"></i>
                    </a>
                </div>
            </div>
        </div>
    </footer>

    <script src="<?php echo BASE_URL; ?>/assets/js/main.js"></script>
</body>
</html>
