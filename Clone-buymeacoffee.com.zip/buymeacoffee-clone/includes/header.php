<?php
// Include config file
require_once __DIR__ . '/../config/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' | ' . SITE_TITLE : SITE_TITLE; ?></title>
    <meta name="description" content="Buy Me a Coffee is the best way for creators and artists to accept support and membership from their fans.">

    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">
                    <a href="<?php echo BASE_URL; ?>">
                        <img src="<?php echo BASE_URL; ?>/assets/img/logo.svg" alt="Buy Me a Coffee">
                    </a>
                </div>

                <ul class="nav-links">
                    <li><a href="<?php echo BASE_URL; ?>/faq.php">FAQ</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/reviews.php">Wall of</a></li>
                    <li class="dropdown">
                        <a href="#">Resources <i class="fas fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="<?php echo BASE_URL; ?>/help-center.php">Help Center</a>
                            <a href="#">iOS</a>
                            <a href="#">Android</a>
                        </div>
                    </li>
                </ul>

                <div class="search">
                    <form action="<?php echo BASE_URL; ?>/search.php" method="GET">
                        <input type="text" name="q" placeholder="Search creators">
                        <button type="submit"><i class="fas fa-search"></i></button>
                    </form>
                </div>

                <div class="auth-buttons">
                    <?php if(isLoggedIn()): ?>
                        <div class="dropdown">
                            <a href="#" class="dropdown-toggle">
                                <?php echo $_SESSION['user_username']; ?> <i class="fas fa-chevron-down"></i>
                            </a>
                            <div class="dropdown-content">
                                <a href="<?php echo BASE_URL; ?>/dashboard.php">Dashboard</a>
                                <a href="<?php echo BASE_URL; ?>/profile.php">Profile</a>
                                <a href="<?php echo BASE_URL; ?>/settings.php">Settings</a>
                                <a href="<?php echo BASE_URL; ?>/logout.php">Logout</a>
                            </div>
                        </div>
                    <?php else: ?>
                        <a href="<?php echo BASE_URL; ?>/login.php" class="btn btn-login">Log in</a>
                        <a href="<?php echo BASE_URL; ?>/signup.php" class="btn btn-signup">Sign up</a>
                    <?php endif; ?>
                </div>
            </nav>
        </div>
    </header>

    <main>
        <?php if(isset($_SESSION['flash_message'])): ?>
            <div class="flash-message <?php echo $_SESSION['flash_message_type']; ?>">
                <?php echo $_SESSION['flash_message']; ?>
            </div>
            <?php unset($_SESSION['flash_message']); unset($_SESSION['flash_message_type']); ?>
        <?php endif; ?>
