<div class="creator-profile">
    <div class="profile-header">
        <div class="profile-avatar">
            <?php if (!empty($creator['avatar'])): ?>
                <img src="<?php echo BASE_URL; ?>/uploads/avatars/<?php echo $creator['avatar']; ?>" alt="<?php echo htmlspecialchars($creator['username']); ?>">
            <?php else: ?>
                <div class="avatar-placeholder"><?php echo strtoupper(substr($creator['username'], 0, 1)); ?></div>
            <?php endif; ?>
        </div>
        <div class="profile-info">
            <h1><?php echo htmlspecialchars($creator['username']); ?></h1>
            <p class="supporters-count"><?php echo $supportersCount; ?> supporters</p>
        </div>
        <div class="profile-actions">
            <button class="btn btn-outline">
                <i class="fas fa-share"></i> Share
            </button>
            <?php if (isLoggedIn() && $_SESSION['user_id'] == $creator['id']): ?>
                <a href="<?php echo BASE_URL; ?>/dashboard.php" class="btn btn-primary">Edit Profile</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="profile-content">
        <div class="profile-main">
            <div class="profile-about">
                <h3>About <?php echo htmlspecialchars($creator['username']); ?></h3>
                <div class="about-content">
                    <?php if (!empty($creator['bio'])): ?>
                        <p><?php echo nl2br(htmlspecialchars($creator['bio'])); ?></p>
                    <?php else: ?>
                        <p class="no-bio">This creator hasn't added any information yet.</p>
                    <?php endif; ?>
                </div>

                <?php if (!empty($creator['website'])): ?>
                    <div class="creator-website">
                        <a href="<?php echo htmlspecialchars($creator['website']); ?>" target="_blank" rel="noopener noreferrer">
                            <i class="fas fa-link"></i> <?php echo htmlspecialchars($creator['website']); ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <div class="recent-supporters">
                <h3>Recent supporters</h3>

                <?php if (count($recentDonations) > 0): ?>
                    <?php foreach ($recentDonations as $donation): ?>
                        <div class="supporter-card">
                            <div class="supporter-header">
                                <div class="supporter-avatar">
                                    <?php if (!empty($donation['supporter_avatar'])): ?>
                                        <img src="<?php echo BASE_URL; ?>/uploads/avatars/<?php echo $donation['supporter_avatar']; ?>" alt="Supporter">
                                    <?php else: ?>
                                        <div class="avatar-placeholder"><?php echo !empty($donation['supporter_name']) ? strtoupper(substr($donation['supporter_name'], 0, 1)) : 'A'; ?></div>
                                    <?php endif; ?>
                                </div>
                                <div class="supporter-info">
                                    <p>
                                        <strong>
                                            <?php echo !empty($donation['supporter_name']) ? htmlspecialchars($donation['supporter_name']) : 'Someone'; ?>
                                        </strong>
                                        bought <?php echo $donation['coffees']; ?> <?php echo $donation['coffees'] > 1 ? 'coffees' : 'coffee'; ?>.
                                    </p>
                                    <span class="donation-date"><?php echo date('M j, Y', strtotime($donation['created_at'])); ?></span>
                                </div>
                            </div>

                            <?php if (!empty($donation['message'])): ?>
                                <div class="supporter-message">
                                    <p><?php echo nl2br(htmlspecialchars($donation['message'])); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>

                    <?php if (count($recentDonations) >= 5): ?>
                        <div class="see-more">
                            <button class="btn btn-text" id="see-more-supporters">See more</button>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="no-supporters">
                        <p>No supporters yet. Be the first one!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="profile-sidebar">
            <div class="coffee-widget">
                <h2>Buy <?php echo htmlspecialchars($creator['username']); ?> a coffee</h2>

                <div class="coffee-options">
                    <div class="coffee-option" data-amount="1">
                        <span class="coffee-icon">☕</span>
                        <span class="coffee-count">1</span>
                    </div>
                    <div class="coffee-option" data-amount="3">
                        <span class="coffee-icon">☕</span>
                        <span class="coffee-count">3</span>
                    </div>
                    <div class="coffee-option" data-amount="5">
                        <span class="coffee-icon">☕</span>
                        <span class="coffee-count">5</span>
                    </div>
                    <div class="coffee-option" data-amount="10">
                        <span class="coffee-icon">☕</span>
                        <span class="coffee-count">10</span>
                    </div>
                </div>

                <form action="<?php echo BASE_URL; ?>/donate.php" method="POST" class="coffee-form">
                    <input type="hidden" name="recipient_id" value="<?php echo $creator['id']; ?>">
                    <input type="hidden" name="coffee_amount" id="coffee-amount" value="1">
                    <input type="hidden" name="is_monthly" id="is-monthly" value="0">

                    <div class="form-group">
                        <input type="text" name="name" class="form-control" placeholder="Name or @yoursocial">
                    </div>

                    <div class="form-group">
                        <textarea name="message" id="message" class="form-control" placeholder="Say something nice..." maxlength="280"></textarea>
                        <div id="char-counter" class="char-counter">280 characters remaining</div>
                    </div>

                    <div class="form-group monthly-toggle">
                        <label for="monthly-toggle" class="toggle-label">
                            <input type="checkbox" id="monthly-toggle">
                            <span class="toggle-slider"></span>
                            Make this monthly
                        </label>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="coffee-button">Support $5</button>
                    </div>
                </form>
            </div>

            <?php if (count($memberships) > 0): ?>
                <div class="memberships-widget">
                    <h2>Memberships</h2>

                    <?php foreach ($memberships as $membership): ?>
                        <div class="membership-tier" data-id="<?php echo $membership['id']; ?>" data-price="<?php echo $membership['price']; ?>">
                            <h3><?php echo htmlspecialchars($membership['title']); ?></h3>
                            <div class="tier-price">$<?php echo $membership['price']; ?>/month</div>
                            <ul class="tier-benefits">
                                <?php foreach ($membership['benefits'] as $benefit): ?>
                                    <li><?php echo htmlspecialchars($benefit); ?></li>
                                <?php endforeach; ?>
                            </ul>
                            <button class="tier-button">Join</button>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Coffee options
    const coffeeOptions = document.querySelectorAll('.coffee-option');
    const coffeeAmount = document.getElementById('coffee-amount');
    const coffeeButton = document.querySelector('.coffee-button');

    coffeeOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove active class from all options
            coffeeOptions.forEach(opt => opt.classList.remove('active'));
            // Add active class to selected option
            this.classList.add('active');

            // Update hidden input and button text
            const amount = this.getAttribute('data-amount');
            coffeeAmount.value = amount;
            const total = amount * 5; // Each coffee is $5
            coffeeButton.textContent = `Support $${total}`;

            // If monthly is checked, add 'monthly' to button text
            if (document.getElementById('monthly-toggle').checked) {
                coffeeButton.textContent += ' monthly';
            }
        });
    });

    // Set first option as active by default
    coffeeOptions[0].classList.add('active');

    // Monthly toggle
    const monthlyToggle = document.getElementById('monthly-toggle');
    const isMonthly = document.getElementById('is-monthly');

    monthlyToggle.addEventListener('change', function() {
        isMonthly.value = this.checked ? '1' : '0';

        // Update button text
        const amount = coffeeAmount.value;
        const total = amount * 5;
        coffeeButton.textContent = `Support $${total}`;

        if (this.checked) {
            coffeeButton.textContent += ' monthly';
        }
    });
});
</script>
