<div class="auth-container">
    <div class="auth-header">
        <a href="<?php echo BASE_URL; ?>" class="auth-logo">
            <img src="<?php echo BASE_URL; ?>/assets/img/logo.svg" alt="Buy Me a Coffee">
        </a>
        <p>Don't have an account? <a href="<?php echo BASE_URL; ?>/signup.php">Sign up</a></p>
    </div>

    <div class="auth-form">
        <h1>Welcome back</h1>

        <form action="<?php echo BASE_URL; ?>/login-process.php" method="POST">
            <div class="form-group">
                <input type="email" name="email" class="form-control" placeholder="Email" required>
            </div>

            <div class="form-group">
                <button type="submit" name="login_email" class="form-button yellow-btn">Continue with email</button>
            </div>
        </form>

        <div class="auth-divider">
            <span>or login with</span>
        </div>

        <div class="social-auth">
            <a href="#" class="social-btn google-btn">
                <img src="<?php echo BASE_URL; ?>/assets/img/icons/google.svg" alt="Google">
                Continue with Google
            </a>

            <a href="#" class="social-btn facebook-btn">
                <img src="<?php echo BASE_URL; ?>/assets/img/icons/facebook.svg" alt="Facebook">
                Continue with Facebook
            </a>

            <a href="#" class="social-btn apple-btn">
                <img src="<?php echo BASE_URL; ?>/assets/img/icons/apple.svg" alt="Apple">
                Continue with Apple
            </a>

            <a href="#" class="social-btn twitter-btn">
                <img src="<?php echo BASE_URL; ?>/assets/img/icons/twitter.svg" alt="Twitter">
                Continue with Twitter
            </a>
        </div>
    </div>
</div>
