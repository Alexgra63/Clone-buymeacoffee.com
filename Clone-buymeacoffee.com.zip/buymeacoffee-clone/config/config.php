<?php
/**
 * Application Configuration
 */

// Session start
session_start();

// Site URL
define('BASE_URL', 'http://localhost/buymeacoffee-clone');

// Site title
define('SITE_TITLE', 'Buy Me a Coffee');

// App root
define('APP_ROOT', dirname(dirname(__FILE__)));

// Include database configuration
require_once('database.php');

// Default coffee price
define('COFFEE_PRICE', 5);

// PayPal settings (would be used in a real application)
define('PAYPAL_CLIENT_ID', 'your-paypal-client-id');
define('PAYPAL_SECRET', 'your-paypal-secret');

// Error reporting (set to 0 in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Time zone
date_default_timezone_set('UTC');

// Helper functions

/**
 * Redirect to a specific page
 *
 * @param string $page Page to redirect to
 * @return void
 */
function redirect($page) {
    header('Location: ' . BASE_URL . '/' . $page);
    exit;
}

/**
 * Check if user is logged in
 *
 * @return boolean
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Sanitize user input
 *
 * @param string $data Input data
 * @return string Sanitized data
 */
function sanitize($data) {
    global $conn;
    return mysqli_real_escape_string($conn, htmlspecialchars(trim($data)));
}

/**
 * Flash message helper
 *
 * @param string $name Message name
 * @param string $message Message text
 * @param string $class CSS class
 * @return void
 */
function flash($name = '', $message = '', $class = 'alert alert-success') {
    if(!empty($name)) {
        if(!empty($message) && empty($_SESSION[$name])) {
            $_SESSION[$name] = $message;
            $_SESSION[$name.'_class'] = $class;
        } else if(empty($message) && !empty($_SESSION[$name])) {
            $class = !empty($_SESSION[$name.'_class']) ? $_SESSION[$name.'_class'] : $class;
            echo '<div class="'.$class.'" id="msg-flash">'.$_SESSION[$name].'</div>';
            unset($_SESSION[$name]);
            unset($_SESSION[$name.'_class']);
        }
    }
}
