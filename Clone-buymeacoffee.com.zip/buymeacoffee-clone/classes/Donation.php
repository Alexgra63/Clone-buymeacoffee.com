<?php
/**
 * Donation Class
 * Handles donations/coffee purchases
 */
class Donation {
    private $conn;
    private $table = 'donations';

    // Donation properties
    public $id;
    public $supporter_id;
    public $recipient_id;
    public $amount;
    public $message;
    public $coffees;
    public $is_monthly;
    public $created_at;

    /**
     * Constructor with DB
     *
     * @param object $db Database connection
     */
    public function __construct($db) {
        $this->conn = $db;
    }

    /**
     * Create a donation
     *
     * @param int $supporter_id Supporter ID
     * @param int $recipient_id Recipient ID
     * @param float $amount Donation amount
     * @param string $message Message
     * @param int $coffees Number of coffees
     * @param boolean $is_monthly Is monthly subscription
     * @return boolean
     */
    public function create($supporter_id, $recipient_id, $amount, $message, $coffees, $is_monthly = false) {
        // Clean the data
        $message = sanitize($message);

        // Prepare query
        $query = "INSERT INTO " . $this->table . "
                  (supporter_id, recipient_id, amount, message, coffees, is_monthly, created_at)
                  VALUES (?, ?, ?, ?, ?, ?, NOW())";

        // Prepare statement
        $stmt = mysqli_prepare($this->conn, $query);

        // Bind parameters
        mysqli_stmt_bind_param($stmt, "iidsii", $supporter_id, $recipient_id, $amount, $message, $coffees, $is_monthly);

        // Execute query
        if(mysqli_stmt_execute($stmt)) {
            return true;
        }

        // Print error if something goes wrong
        printf("Error: %s.\n", mysqli_stmt_error($stmt));

        return false;
    }

    /**
     * Get donations by recipient
     *
     * @param int $recipient_id Recipient ID
     * @param int $limit Limit of results
     * @return array Donations
     */
    public function getByRecipient($recipient_id, $limit = 10) {
        $query = "SELECT d.*, u.username as supporter_name
                  FROM " . $this->table . " d
                  LEFT JOIN users u ON d.supporter_id = u.id
                  WHERE d.recipient_id = ?
                  ORDER BY d.created_at DESC
                  LIMIT ?";

        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "ii", $recipient_id, $limit);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        $donations = [];

        while($row = mysqli_fetch_assoc($result)) {
            $donations[] = $row;
        }

        return $donations;
    }

    /**
     * Get donations by supporter
     *
     * @param int $supporter_id Supporter ID
     * @param int $limit Limit of results
     * @return array Donations
     */
    public function getBySupporter($supporter_id, $limit = 10) {
        $query = "SELECT d.*, u.username as recipient_name
                  FROM " . $this->table . " d
                  LEFT JOIN users u ON d.recipient_id = u.id
                  WHERE d.supporter_id = ?
                  ORDER BY d.created_at DESC
                  LIMIT ?";

        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "ii", $supporter_id, $limit);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        $donations = [];

        while($row = mysqli_fetch_assoc($result)) {
            $donations[] = $row;
        }

        return $donations;
    }

    /**
     * Get total coffees donated to a recipient
     *
     * @param int $recipient_id Recipient ID
     * @return int Total coffees
     */
    public function getTotalCoffees($recipient_id) {
        $query = "SELECT SUM(coffees) as total_coffees
                  FROM " . $this->table . "
                  WHERE recipient_id = ?";

        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "i", $recipient_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);

        return $row['total_coffees'] ?? 0;
    }

    /**
     * Get total amount donated to a recipient
     *
     * @param int $recipient_id Recipient ID
     * @return float Total amount
     */
    public function getTotalAmount($recipient_id) {
        $query = "SELECT SUM(amount) as total_amount
                  FROM " . $this->table . "
                  WHERE recipient_id = ?";

        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "i", $recipient_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);

        return $row['total_amount'] ?? 0;
    }

    /**
     * Get monthly subscribers
     *
     * @param int $recipient_id Recipient ID
     * @return int Number of monthly subscribers
     */
    public function getMonthlySubscribers($recipient_id) {
        $query = "SELECT COUNT(DISTINCT supporter_id) as subscribers
                  FROM " . $this->table . "
                  WHERE recipient_id = ? AND is_monthly = 1";

        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "i", $recipient_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);

        return $row['subscribers'] ?? 0;
    }
}
