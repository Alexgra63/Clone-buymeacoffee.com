<?php
/**
 * Membership Class
 * Handles creator memberships
 */
class Membership {
    private $conn;
    private $table = 'memberships';

    // Membership properties
    public $id;
    public $creator_id;
    public $title;
    public $description;
    public $price;
    public $benefits;
    public $created_at;

    /**
     * Constructor with DB
     *
     * @param object $db Database connection
     */
    public function __construct($db) {
        $this->conn = $db;
    }

    /**
     * Create a membership tier
     *
     * @param int $creator_id Creator ID
     * @param string $title Membership title
     * @param string $description Membership description
     * @param float $price Membership price
     * @param array $benefits Membership benefits
     * @return boolean
     */
    public function create($creator_id, $title, $description, $price, $benefits) {
        // Clean the data
        $title = sanitize($title);
        $description = sanitize($description);

        // Encode benefits as JSON
        $benefits_json = json_encode($benefits);

        // Prepare query
        $query = "INSERT INTO " . $this->table . "
                  (creator_id, title, description, price, benefits, created_at)
                  VALUES (?, ?, ?, ?, ?, NOW())";

        // Prepare statement
        $stmt = mysqli_prepare($this->conn, $query);

        // Bind parameters
        mysqli_stmt_bind_param($stmt, "issds", $creator_id, $title, $description, $price, $benefits_json);

        // Execute query
        if(mysqli_stmt_execute($stmt)) {
            return true;
        }

        // Print error if something goes wrong
        printf("Error: %s.\n", mysqli_stmt_error($stmt));

        return false;
    }

    /**
     * Update a membership tier
     *
     * @param int $id Membership ID
     * @param array $data Updated data
     * @return boolean
     */
    public function update($id, $data) {
        // Clean the data
        $title = sanitize($data['title']);
        $description = sanitize($data['description']);
        $price = $data['price'];

        // Encode benefits as JSON
        $benefits_json = json_encode($data['benefits']);

        // Prepare query
        $query = "UPDATE " . $this->table . "
                  SET title = ?, description = ?, price = ?, benefits = ?
                  WHERE id = ?";

        // Prepare statement
        $stmt = mysqli_prepare($this->conn, $query);

        // Bind parameters
        mysqli_stmt_bind_param($stmt, "ssdsi", $title, $description, $price, $benefits_json, $id);

        // Execute query
        if(mysqli_stmt_execute($stmt)) {
            return true;
        }

        return false;
    }

    /**
     * Delete a membership tier
     *
     * @param int $id Membership ID
     * @return boolean
     */
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE id = ?";
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "i", $id);

        if(mysqli_stmt_execute($stmt)) {
            return true;
        }

        return false;
    }

    /**
     * Get a membership tier by ID
     *
     * @param int $id Membership ID
     * @return array|boolean Membership data or false
     */
    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = ?";
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if(mysqli_num_rows($result) > 0) {
            $membership = mysqli_fetch_assoc($result);
            // Decode benefits JSON
            $membership['benefits'] = json_decode($membership['benefits'], true);
            return $membership;
        }

        return false;
    }

    /**
     * Get membership tiers by creator
     *
     * @param int $creator_id Creator ID
     * @return array Membership tiers
     */
    public function getByCreator($creator_id) {
        $query = "SELECT * FROM " . $this->table . " WHERE creator_id = ? ORDER BY price ASC";
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "i", $creator_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        $memberships = [];

        while($row = mysqli_fetch_assoc($result)) {
            // Decode benefits JSON
            $row['benefits'] = json_decode($row['benefits'], true);
            $memberships[] = $row;
        }

        return $memberships;
    }

    /**
     * Get subscribers count for a membership tier
     *
     * @param int $id Membership ID
     * @return int Number of subscribers
     */
    public function getSubscribersCount($id) {
        $query = "SELECT COUNT(*) as subscribers_count
                  FROM membership_subscribers
                  WHERE membership_id = ?";
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);

        return $row['subscribers_count'] ?? 0;
    }

    /**
     * Get total revenue for a creator's memberships
     *
     * @param int $creator_id Creator ID
     * @return float Total revenue
     */
    public function getTotalRevenue($creator_id) {
        $query = "SELECT SUM(m.price) as total_revenue
                  FROM membership_subscribers ms
                  JOIN " . $this->table . " m ON ms.membership_id = m.id
                  WHERE m.creator_id = ?";
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "i", $creator_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);

        return $row['total_revenue'] ?? 0;
    }
}
