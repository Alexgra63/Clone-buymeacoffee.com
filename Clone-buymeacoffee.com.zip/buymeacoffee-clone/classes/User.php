<?php
/**
 * User Class
 * Handles user registration, authentication, and profile management
 */
class User {
    private $conn;
    private $table = 'users';

    // User properties
    public $id;
    public $username;
    public $email;
    public $password;
    public $bio;
    public $created_at;

    /**
     * Constructor with DB
     *
     * @param object $db Database connection
     */
    public function __construct($db) {
        $this->conn = $db;
    }

    /**
     * Register user
     *
     * @param string $username Username
     * @param string $email Email
     * @param string $password Password
     * @return boolean
     */
    public function register($username, $email, $password) {
        // Clean the data
        $username = sanitize($username);
        $email = sanitize($email);

        // Check if username exists
        if($this->findUserByUsername($username)) {
            return false;
        }

        // Check if email exists
        if($this->findUserByEmail($email)) {
            return false;
        }

        // Hash password
        $password = password_hash($password, PASSWORD_DEFAULT);

        // Prepare query
        $query = "INSERT INTO " . $this->table . " (username, email, password, created_at)
                  VALUES (?, ?, ?, NOW())";

        // Prepare statement
        $stmt = mysqli_prepare($this->conn, $query);

        // Bind parameters
        mysqli_stmt_bind_param($stmt, "sss", $username, $email, $password);

        // Execute query
        if(mysqli_stmt_execute($stmt)) {
            return true;
        }

        // Print error if something goes wrong
        printf("Error: %s.\n", mysqli_stmt_error($stmt));

        return false;
    }

    /**
     * Login user
     *
     * @param string $email Email
     * @param string $password Password
     * @return boolean
     */
    public function login($email, $password) {
        // Clean the data
        $email = sanitize($email);

        // Find user by email
        $user = $this->findUserByEmail($email);

        if($user) {
            // Verify password
            if(password_verify($password, $user['password'])) {
                // Set user session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_username'] = $user['username'];
                $_SESSION['user_email'] = $user['email'];

                return true;
            }
        }

        return false;
    }

    /**
     * Find user by username
     *
     * @param string $username Username
     * @return array|boolean User data or false
     */
    public function findUserByUsername($username) {
        $query = "SELECT * FROM " . $this->table . " WHERE username = ?";
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if(mysqli_num_rows($result) > 0) {
            return mysqli_fetch_assoc($result);
        }

        return false;
    }

    /**
     * Find user by email
     *
     * @param string $email Email
     * @return array|boolean User data or false
     */
    public function findUserByEmail($email) {
        $query = "SELECT * FROM " . $this->table . " WHERE email = ?";
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if(mysqli_num_rows($result) > 0) {
            return mysqli_fetch_assoc($result);
        }

        return false;
    }

    /**
     * Get user by ID
     *
     * @param int $id User ID
     * @return array|boolean User data or false
     */
    public function getUserById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = ?";
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if(mysqli_num_rows($result) > 0) {
            return mysqli_fetch_assoc($result);
        }

        return false;
    }

    /**
     * Update user profile
     *
     * @param int $id User ID
     * @param array $data Profile data to update
     * @return boolean
     */
    public function updateProfile($id, $data) {
        $username = sanitize($data['username']);
        $bio = sanitize($data['bio']);

        $query = "UPDATE " . $this->table . " SET username = ?, bio = ? WHERE id = ?";
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "ssi", $username, $bio, $id);

        if(mysqli_stmt_execute($stmt)) {
            return true;
        }

        return false;
    }

    /**
     * Get user supporters count
     *
     * @param int $id User ID
     * @return int Number of supporters
     */
    public function getSupportersCount($id) {
        $query = "SELECT COUNT(DISTINCT supporter_id) as supporters_count
                  FROM donations
                  WHERE recipient_id = ?";
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);

        return $row['supporters_count'] ?? 0;
    }

    /**
     * Logout user
     *
     * @return void
     */
    public function logout() {
        unset($_SESSION['user_id']);
        unset($_SESSION['user_username']);
        unset($_SESSION['user_email']);
        session_destroy();
    }
}
